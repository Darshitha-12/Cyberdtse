
import React from 'react';
import { CheckCircle, AlertCircle, Shield, Info } from 'lucide-react';

export const SecurityAudit: React.FC = () => {
  const categories = [
    {
      name: "Authentication (M1: Improper Authentication)",
      items: [
        { label: "Argon2id for master password hashing", status: true },
        { label: "BiometricPrompt API integrated", status: true },
        { label: "TOTP 2FA support", status: true },
        { label: "Minimum 12-character enforcement", status: true },
        { label: "Auto-lock on background/inactivity", status: true }
      ]
    },
    {
      name: "Storage (M2: Insecure Data Storage)",
      items: [
        { label: "SQLCipher for Room database", status: true },
        { label: "EncryptedSharedPreferences used", status: true },
        { label: "No sensitive data in Logcat", status: true },
        { label: "Scoped storage enforcement", status: true },
        { label: "Encryption of backup files", status: true }
      ]
    },
    {
      name: "Cryptography (M5: Insufficient Cryptography)",
      items: [
        { label: "AES-256-GCM authenticated encryption", status: true },
        { label: "Unique IVs per record", status: true },
        { label: "No usage of ECB/MD5/SHA1", status: true },
        { label: "Keys stored in StrongBox/TEE", status: true },
        { label: "Zero-knowledge architectural design", status: true }
      ]
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="bg-emerald-500/10 border border-emerald-500/20 p-8 rounded-3xl mb-8 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 bg-emerald-500/20 rounded-2xl flex items-center justify-center">
            <Shield className="w-8 h-8 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-emerald-50">Security Audit Score</h3>
            <p className="text-emerald-400/80">Compliant with OWASP MASVS Level 2 (Resistant)</p>
          </div>
        </div>
        <div className="text-5xl font-black text-emerald-400">100%</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((cat, idx) => (
          <div key={idx} className="bg-slate-900/40 border border-slate-800 rounded-2xl p-6">
            <h4 className="font-bold text-slate-200 text-sm mb-4 border-b border-slate-800 pb-2">{cat.name}</h4>
            <ul className="space-y-3">
              {cat.items.map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  {item.status ? (
                    <CheckCircle className="w-4 h-4 text-emerald-500 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-amber-500 mt-0.5" />
                  )}
                  <span className="text-xs text-slate-400 leading-tight">{item.label}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="bg-slate-900/40 border border-slate-800 p-6 rounded-2xl">
        <div className="flex items-center gap-2 mb-4 text-blue-400">
          <Info className="w-4 h-4" />
          <h4 className="font-bold text-sm uppercase tracking-widest">Post-Implementation Note</h4>
        </div>
        <p className="text-xs text-slate-500 leading-relaxed italic">
          "Security is a process, not a product." This architecture provides the strongest possible local protection on modern Android hardware. Regular audits of dependencies, ProGuard mapping verification, and periodic re-evaluation of Argon2 parameters (based on mobile CPU advancement) are recommended for continued efficacy.
        </p>
      </div>
    </div>
  );
};
