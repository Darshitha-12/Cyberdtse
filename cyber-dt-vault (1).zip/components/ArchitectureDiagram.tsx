
import React from 'react';
import { Smartphone, Database, Lock, Shield, Server, Box } from 'lucide-react';

export const ArchitectureDiagram: React.FC = () => {
  return (
    <div className="animate-in slide-in-from-bottom-4 duration-500">
      <div className="mb-12 text-center">
        <h3 className="text-3xl font-bold text-white mb-4">Clean Architecture & MVVM</h3>
        <p className="text-slate-400 max-w-2xl mx-auto">
          Isolation of concerns ensures that business logic and cryptographic operations are decoupled from UI and external data sources.
        </p>
      </div>

      <div className="relative flex flex-col items-center space-y-8">
        {/* UI Layer */}
        <div className="w-full max-w-3xl p-6 bg-slate-900 border-2 border-slate-700 rounded-xl flex flex-col items-center group hover:border-blue-500 transition-colors">
          <div className="flex items-center gap-3 mb-4">
            <Smartphone className="text-blue-400" />
            <span className="font-bold text-blue-100 tracking-wider">UI / PRESENTATION LAYER</span>
          </div>
          <div className="flex gap-4 w-full">
            <div className="flex-1 p-3 bg-slate-800 rounded border border-slate-700 text-center text-xs font-bold text-slate-300">Jetpack Compose / Fragment</div>
            <div className="flex-1 p-3 bg-slate-800 rounded border border-slate-700 text-center text-xs font-bold text-slate-300">ViewModels (State Management)</div>
          </div>
        </div>

        <div className="w-0.5 h-8 bg-slate-700"></div>

        {/* Use Cases / Domain Layer */}
        <div className="w-full max-w-3xl p-6 bg-emerald-950/20 border-2 border-emerald-900/50 rounded-xl flex flex-col items-center group hover:border-emerald-500 transition-colors">
          <div className="flex items-center gap-3 mb-4">
            <Lock className="text-emerald-400" />
            <span className="font-bold text-emerald-100 tracking-wider">DOMAIN LAYER (SECURE BUSINESS LOGIC)</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 w-full">
            <UseCase label="EncryptRecordUseCase" />
            <UseCase label="DeriveMasterKeyUseCase" />
            <UseCase label="AuthenticateUserUseCase" />
            <UseCase label="ValidateBiometricsUseCase" />
            <UseCase label="SecureBackupUseCase" />
            <UseCase label="WipeVaultUseCase" />
          </div>
        </div>

        <div className="w-0.5 h-8 bg-slate-700"></div>

        {/* Data Layer */}
        <div className="w-full max-w-3xl p-6 bg-slate-900 border-2 border-slate-700 rounded-xl flex flex-col items-center group hover:border-purple-500 transition-colors">
          <div className="flex items-center gap-3 mb-4">
            <Database className="text-purple-400" />
            <span className="font-bold text-purple-100 tracking-wider">DATA LAYER & REPOSITORIES</span>
          </div>
          <div className="flex flex-col md:flex-row gap-6 w-full">
            <div className="flex-1 flex flex-col gap-2">
              <span className="text-[10px] text-slate-500 font-bold uppercase mb-1">Local Storage</span>
              <StorageBox icon={<Database size={16}/>} label="Encrypted Room (SQLCipher)" />
              <StorageBox icon={<Box size={16}/>} label="Encrypted SharedPreferences" />
            </div>
            <div className="flex-1 flex flex-col gap-2">
              <span className="text-[10px] text-slate-500 font-bold uppercase mb-1">Security Modules</span>
              <StorageBox icon={<Shield size={16}/>} label="Android Keystore Provider" />
              <StorageBox icon={<Server size={16}/>} label="External API (2FA/Sync)" />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-12 bg-slate-900/50 p-6 rounded-xl border border-slate-800">
        <h4 className="font-bold text-slate-100 mb-3 flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-400" />
          Hardware Root of Trust
        </h4>
        <div className="text-sm text-slate-400 leading-relaxed space-y-2">
          <p>This architecture is anchored by the <span className="text-emerald-400 font-bold">Android Keystore System</span>. Even if the application process is compromised via memory analysis, the Master Key remains inside the <span className="text-white italic">Trusted Execution Environment (TEE)</span> or <span className="text-white italic">StrongBox SE</span>.</p>
          <p>Key attributes used: <code className="text-xs bg-slate-800 px-1 py-0.5 rounded text-emerald-300">userAuthenticationRequired(true)</code> and <code className="text-xs bg-slate-800 px-1 py-0.5 rounded text-emerald-300">invalidatedByBiometricEnrollment(true)</code>.</p>
        </div>
      </div>
    </div>
  );
};

const UseCase: React.FC<{ label: string }> = ({ label }) => (
  <div className="p-2 bg-emerald-500/10 rounded border border-emerald-500/20 text-center text-[10px] font-bold text-emerald-400 mono truncate">
    {label}
  </div>
);

const StorageBox: React.FC<{ icon: React.ReactNode; label: string }> = ({ icon, label }) => (
  <div className="flex items-center gap-2 p-2 bg-slate-800 rounded border border-slate-700 text-xs font-medium text-slate-300">
    <div className="text-slate-500">{icon}</div>
    {label}
  </div>
);
