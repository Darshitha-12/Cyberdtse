
import React, { useState } from 'react';
import { FileCode, Copy, Check, Info } from 'lucide-react';

export const CodeSnippets: React.FC = () => {
  const [copied, setCopied] = useState<string | null>(null);

  const snippets = [
    {
      id: 'derivation',
      title: '1. Argon2id Key Derivation',
      desc: 'Generating a high-entropy master key from a user password.',
      code: `
// Kotlin implementation using Argon2id (recommended over PBKDF2)
val salt = SecureRandom().generateSeed(16)
val config = Argon2Kt.createDefaultConfig()
val hash = Argon2Kt().hash(
    mode = Argon2Mode.ARGON2_ID,
    password = masterPassword.toByteArray(),
    salt = salt,
    config = config // 64MB, 4 iterations, 4 parallelism
)
// Use hash as the source for your AES SecretKey`
    },
    {
      id: 'keystore',
      title: '2. Keystore Protection',
      desc: 'Protecting the encryption key inside hardware-backed storage.',
      code: `
val keyGenerator = KeyGenerator.getInstance(
    KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"
)
val spec = KeyGenParameterSpec.Builder(
    "VAULT_MASTER_KEY",
    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
 .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
 .setKeySize(256)
 .setUserAuthenticationRequired(true) // Requires Biometric/PIN
 .build()

keyGenerator.init(spec)
val secretKey = keyGenerator.generateKey()`
    },
    {
      id: 'encryption',
      title: '3. AES-GCM Cipher',
      desc: 'Encrypting vault records with authenticated encryption.',
      code: `
fun encrypt(data: String, key: SecretKey): Pair<ByteArray, ByteArray> {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key)
    val iv = cipher.iv
    val ciphertext = cipher.doFinal(data.toByteArray())
    return Pair(iv, ciphertext)
}

fun decrypt(iv: ByteArray, ciphertext: ByteArray, key: SecretKey): String {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    val spec = GCMParameterSpec(128, iv)
    cipher.init(Cipher.DECRYPT_MODE, key, spec)
    return String(cipher.doFinal(ciphertext))
}`
    }
  ];

  const copy = (txt: string, id: string) => {
    navigator.clipboard.writeText(txt);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-emerald-500/10 border border-emerald-500/20 p-6 rounded-2xl flex gap-4">
        <div className="bg-emerald-500/20 w-12 h-12 rounded-xl flex items-center justify-center shrink-0">
          <Info className="text-emerald-400" />
        </div>
        <div>
          <h4 className="font-bold text-white mb-1">Android Security Principles</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            These snippets follow Android's official security best practices: hardware-backed keys, mandatory user authentication, and authenticated encryption (GCM).
          </p>
        </div>
      </div>

      {snippets.map(s => (
        <div key={s.id} className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="px-6 py-4 bg-slate-900/50 border-b border-slate-800 flex justify-between items-center">
            <div>
              <h5 className="font-bold text-sm text-slate-200">{s.title}</h5>
              <p className="text-[10px] text-slate-500">{s.desc}</p>
            </div>
            <button onClick={() => copy(s.code, s.id)} className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
              {copied === s.id ? <Check size={16} className="text-emerald-500" /> : <Copy size={16} className="text-slate-500" />}
            </button>
          </div>
          <div className="p-6 bg-slate-950">
            <pre className="text-[11px] mono text-slate-300 overflow-x-auto custom-scrollbar leading-relaxed">
              {s.code.trim()}
            </pre>
          </div>
        </div>
      ))}
    </div>
  );
};
