
import React from 'react';
import { Key, Lock, Fingerprint, Database, ArrowRight, ShieldCheck } from 'lucide-react';

export const EncryptionFlow: React.FC = () => {
  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="text-center">
        <h3 className="text-3xl font-bold text-white mb-4">Zero-Knowledge Key Derivation</h3>
        <p className="text-slate-400 max-w-3xl mx-auto">
          IronVault uses multi-stage derivation to ensure that the Master Password is never stored and that keys are hardware-isolated.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Derivation Step */}
        <div className="bg-slate-900/40 border border-slate-800 p-8 rounded-2xl relative">
          <div className="absolute -top-4 -left-4 w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/20">1</div>
          <h4 className="text-xl font-bold mb-6 text-blue-400">Argon2id Derivation</h4>
          <div className="space-y-4">
            <FlowStep icon={<Lock size={16}/>} label="Master Password" desc="Min 12 characters" />
            <div className="flex justify-center py-2"><ArrowRight className="rotate-90 text-slate-600" /></div>
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center">
              <div className="text-xs font-bold text-slate-500 uppercase mb-2">Algorithm: Argon2id</div>
              <div className="text-[10px] text-slate-400 mono">Memory: 64MB | Parallelism: 4 | Salt: 16B</div>
            </div>
            <div className="flex justify-center py-2"><ArrowRight className="rotate-90 text-slate-600" /></div>
            <FlowStep icon={<Key size={16}/>} label="Stretching Key" desc="Transient in-memory buffer" />
          </div>
        </div>

        {/* Keystore Step */}
        <div className="bg-slate-900/40 border border-slate-800 p-8 rounded-2xl relative">
          <div className="absolute -top-4 -left-4 w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center font-bold text-white shadow-lg shadow-emerald-500/20">2</div>
          <h4 className="text-xl font-bold mb-6 text-emerald-400">Android Keystore Binding</h4>
          <div className="space-y-4">
            <FlowStep icon={<ShieldCheck size={16}/>} label="Hardware Key" desc="Stored in TEE/StrongBox" />
            <div className="flex justify-center py-2"><ArrowRight className="rotate-90 text-slate-600" /></div>
            <div className="p-4 bg-emerald-950/20 rounded-xl border border-emerald-900/50 text-center">
              <div className="text-xs font-bold text-emerald-500 uppercase mb-2">Keystore Wrapped AES</div>
              <p className="text-[10px] text-slate-400 leading-relaxed">
                The stretching key is used to unwrap a Vault Master Key (VMK) stored in the hardware. Access is gated by BiometricPrompt.
              </p>
            </div>
            <div className="flex justify-center py-2"><ArrowRight className="rotate-90 text-slate-600" /></div>
            <FlowStep icon={<Fingerprint size={16}/>} label="Unlocked Vault Key" desc="Valid for current session" />
          </div>
        </div>
      </div>

      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-8">
        <h4 className="text-xl font-bold mb-8 flex items-center gap-3">
          <Database className="w-6 h-6 text-purple-400" />
          Data Encryption Standard (AES-256-GCM)
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <DetailBox 
            title="Authenticated Encryption" 
            desc="GCM mode provides both confidentiality and integrity, preventing 'bit-flipping' attacks on stored ciphertext." 
          />
          <DetailBox 
            title="Unique Per-Record IV" 
            desc="Initialization Vectors (96-bit) are randomly generated for every single entry, ensuring identical plaintexts result in unique ciphertexts." 
          />
          <DetailBox 
            title="Zeroing Memory" 
            desc="Sensitive CharArrays and ByteBuffers are overwritten with zeros immediately after crypto operations to prevent heap dumping." 
          />
        </div>
      </div>
    </div>
  );
};

const FlowStep: React.FC<{ icon: React.ReactNode; label: string; desc: string }> = ({ icon, label, desc }) => (
  <div className="flex items-center gap-4 p-4 bg-slate-950/50 rounded-xl border border-slate-800">
    <div className="p-2 bg-slate-800 rounded-lg text-slate-400">
      {icon}
    </div>
    <div>
      <div className="text-sm font-bold text-slate-200">{label}</div>
      <div className="text-[10px] text-slate-500">{desc}</div>
    </div>
  </div>
);

const DetailBox: React.FC<{ title: string; desc: string }> = ({ title, desc }) => (
  <div className="p-6 bg-slate-950/40 border border-slate-800 rounded-xl">
    <h5 className="text-sm font-bold text-slate-300 mb-2 uppercase tracking-wide">{title}</h5>
    <p className="text-xs text-slate-500 leading-relaxed">{desc}</p>
  </div>
);
