
import React from 'react';
import { AlertTriangle, ShieldAlert, Target, ShieldCheck } from 'lucide-react';

export const ThreatModel: React.FC = () => {
  const strideData = [
    { 
      type: 'Spoofing', 
      threat: 'Malicious app spoofing biometric prompt', 
      mitigation: 'Use system-level BiometricPrompt; verify package signature; integrate biometric signature with Keystore operations.'
    },
    { 
      type: 'Tampering', 
      threat: 'Physical access: modifying SQLite database file', 
      mitigation: 'SQLCipher with 256-bit AES + Page Integrity checks. Data is cryptographically authenticated.'
    },
    { 
      type: 'Repudiation', 
      threat: 'Unauthorized access via secondary biometric profile', 
      mitigation: 'Set invalidatedByBiometricEnrollment(true) on Keystore keys. All keys wipe if fingerprint database changes.'
    },
    { 
      type: 'Information Disclosure', 
      threat: 'Memory scraping or screenshot leakage', 
      mitigation: 'FLAG_SECURE on all sensitive Activity/Window contexts; zero-out buffers; use custom keyboards or obfuscate inputs.'
    },
    { 
      type: 'Denial of Service', 
      threat: 'Brute-forcing master password to lock vault', 
      mitigation: 'Progressive rate-limiting (exponential backoff) and auto-wipe after 10 failed attempts.'
    },
    { 
      type: 'Elevation of Privilege', 
      threat: 'Root user bypassing sandbox restrictions', 
      mitigation: 'Multiple root detection checks (Superuser.apk, busybox, test-keys). App refuses to run on compromised devices.'
    }
  ];

  return (
    <div className="space-y-10 animate-in fade-in zoom-in-95 duration-500">
      <div className="flex flex-col md:flex-row gap-8 items-start">
        <div className="flex-1">
          <h3 className="text-3xl font-bold text-white mb-4">STRIDE Analysis</h3>
          <p className="text-slate-400 mb-6">
            Detailed security assessment based on the Microsoft STRIDE model for local Android assets.
          </p>
          <div className="grid grid-cols-1 gap-4">
            {strideData.map((item, idx) => (
              <div key={idx} className="bg-slate-900/40 border border-slate-800 rounded-xl overflow-hidden">
                <div className="flex">
                  <div className={`w-2 ${idx % 2 === 0 ? 'bg-red-500' : 'bg-orange-500'}`}></div>
                  <div className="p-4 flex-1">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-xs font-black uppercase tracking-tighter text-slate-500">{item.type}</span>
                      <ShieldAlert className="w-4 h-4 text-slate-600" />
                    </div>
                    <div className="text-sm font-bold text-slate-200 mb-2">{item.threat}</div>
                    <div className="text-xs text-slate-400 italic bg-slate-950 p-2 rounded border border-slate-800">
                      <span className="text-emerald-500 font-bold not-italic">Mitigation:</span> {item.mitigation}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="w-full md:w-80 space-y-6">
          <div className="bg-red-950/20 border border-red-900/30 p-6 rounded-2xl">
            <h4 className="text-red-400 font-bold flex items-center gap-2 mb-4">
              <Target className="w-4 h-4" />
              Primary Attack Vector
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Physical access by a sophisticated attacker with forensic tools. The vault assumes the device storage can be imaged. Security relies entirely on the <span className="text-red-300">work factor of Argon2id</span> and the <span className="text-red-300">hardware isolation</span> of the Android Keystore.
            </p>
          </div>

          <div className="bg-emerald-950/20 border border-emerald-900/30 p-6 rounded-2xl">
            <h4 className="text-emerald-400 font-bold flex items-center gap-2 mb-4">
              <ShieldCheck className="w-4 h-4" />
              Security Hardening
            </h4>
            <ul className="text-xs text-slate-400 space-y-3">
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 bg-emerald-500 rounded-full"></div>
                Root/Jailbreak Detection
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 bg-emerald-500 rounded-full"></div>
                Debugger/Emulator Check
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 bg-emerald-500 rounded-full"></div>
                Certificate Pinning (Sync)
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 bg-emerald-500 rounded-full"></div>
                No Logcat sensitive data
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
