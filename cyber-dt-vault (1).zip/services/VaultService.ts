
/**
 * VaultService simulates the Android IronVault security engine.
 * Implements a "Vault Master Key" (VMK) pattern:
 * 1. A random VMK is generated.
 * 2. VMK is encrypted by the Master Password (stored in ENC_VMK_MASTER).
 * 3. VMK is encrypted by the Recovery Key (stored in ENC_VMK_RECOVERY).
 * 4. All vault data is encrypted by the VMK (stored in DATA_BLOB).
 */

export interface VaultItem {
  id: string;
  title: string;
  username: string;
  password: string;
}

const SALT_MASTER = 'ironvault_salt_master';
const SALT_RECOVERY = 'ironvault_salt_recovery';
const ENC_VMK_MASTER = 'ironvault_vmk_master';
const ENC_VMK_RECOVERY = 'ironvault_vmk_recovery';
const DATA_BLOB = 'ironvault_data_blob';
const ITERATIONS = 100000;

export class VaultService {
  private static currentVMK: CryptoKey | null = null;

  static async hasExistingVault(): Promise<boolean> {
    return !!localStorage.getItem(ENC_VMK_MASTER);
  }

  /**
   * Initializes a new vault with a random VMK protected by password and recovery key.
   */
  static async initializeVault(password: string): Promise<string> {
    // 1. Generate Salts
    const saltM = window.crypto.getRandomValues(new Uint8Array(16));
    const saltR = window.crypto.getRandomValues(new Uint8Array(16));
    localStorage.setItem(SALT_MASTER, this.bufToBase64(saltM));
    localStorage.setItem(SALT_RECOVERY, this.bufToBase64(saltR));

    // 2. Generate random VMK (AES-256)
    const vmk = await window.crypto.subtle.generateKey(
      { name: "AES-GCM", length: 256 },
      true, // extractable is necessary to re-wrap it during password resets
      ["encrypt", "decrypt"]
    );
    this.currentVMK = vmk;
    const vmkRaw = await window.crypto.subtle.exportKey("raw", vmk);

    // 3. Protect VMK with Password
    await this.protectVMK(new Uint8Array(vmkRaw), password, saltM, ENC_VMK_MASTER);

    // 4. Protect VMK with Recovery Key
    const recoveryKey = this.generateRecoveryHex();
    await this.protectVMK(new Uint8Array(vmkRaw), recoveryKey, saltR, ENC_VMK_RECOVERY);

    // 5. Save initial empty data
    await this.saveVault([]);

    return recoveryKey;
  }

  /**
   * Unlocks the vault using the master password.
   */
  static async unlockVault(password: string): Promise<VaultItem[]> {
    const saltM = this.base64ToBuf(localStorage.getItem(SALT_MASTER)!);
    const encVMK = this.base64ToBuf(localStorage.getItem(ENC_VMK_MASTER)!);
    
    try {
      const vmkRaw = await this.decryptBlob(encVMK, password, saltM);
      // CRITICAL: extractable must be true so resetMasterPassword can export it
      this.currentVMK = await window.crypto.subtle.importKey("raw", vmkRaw, "AES-GCM", true, ["encrypt", "decrypt"]);
      return await this.loadData();
    } catch (e) {
      throw new Error("Invalid master password");
    }
  }

  /**
   * Recovers the vault using the hex recovery key.
   */
  static async recoverVault(recoveryKey: string): Promise<VaultItem[]> {
    const saltR = this.base64ToBuf(localStorage.getItem(SALT_RECOVERY)!);
    const encVMK = this.base64ToBuf(localStorage.getItem(ENC_VMK_RECOVERY)!);

    try {
      const vmkRaw = await this.decryptBlob(encVMK, recoveryKey, saltR);
      // CRITICAL: extractable must be true so resetMasterPassword can export it
      this.currentVMK = await window.crypto.subtle.importKey("raw", vmkRaw, "AES-GCM", true, ["encrypt", "decrypt"]);
      return await this.loadData();
    } catch (e) {
      throw new Error("Invalid recovery key");
    }
  }

  /**
   * Sets a new master password without losing data.
   */
  static async resetMasterPassword(newPassword: string): Promise<void> {
    if (!this.currentVMK) throw new Error("Vault not unlocked");
    // This requires currentVMK to be extractable: true
    const vmkRaw = await window.crypto.subtle.exportKey("raw", this.currentVMK);
    const saltM = window.crypto.getRandomValues(new Uint8Array(16));
    localStorage.setItem(SALT_MASTER, this.bufToBase64(saltM));
    await this.protectVMK(new Uint8Array(vmkRaw), newPassword, saltM, ENC_VMK_MASTER);
  }

  /**
   * Encrypts the current item list using the VMK.
   */
  static async saveVault(items: VaultItem[]): Promise<void> {
    if (!this.currentVMK) throw new Error("Vault not unlocked");
    
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const plaintext = new TextEncoder().encode(JSON.stringify(items));
    const encrypted = await window.crypto.subtle.encrypt({ name: "AES-GCM", iv }, this.currentVMK, plaintext);

    const combined = new Uint8Array(iv.length + encrypted.byteLength);
    combined.set(iv);
    combined.set(new Uint8Array(encrypted), iv.length);
    localStorage.setItem(DATA_BLOB, this.bufToBase64(combined));
  }

  private static async loadData(): Promise<VaultItem[]> {
    const data = localStorage.getItem(DATA_BLOB);
    if (!data) return [];
    const combined = this.base64ToBuf(data);
    const iv = combined.slice(0, 12);
    const ciphertext = combined.slice(12);

    const decrypted = await window.crypto.subtle.decrypt({ name: "AES-GCM", iv }, this.currentVMK!, ciphertext);
    return JSON.parse(new TextDecoder().decode(decrypted));
  }

  private static async protectVMK(vmkRaw: Uint8Array, secret: string, salt: Uint8Array, key: string) {
    const derivedKey = await this.deriveKey(secret, salt);
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await window.crypto.subtle.encrypt({ name: "AES-GCM", iv }, derivedKey, vmkRaw);
    const combined = new Uint8Array(iv.length + encrypted.byteLength);
    combined.set(iv);
    combined.set(new Uint8Array(encrypted), iv.length);
    localStorage.setItem(key, this.bufToBase64(combined));
  }

  private static async decryptBlob(combined: Uint8Array, secret: string, salt: Uint8Array): Promise<Uint8Array> {
    const derivedKey = await this.deriveKey(secret, salt);
    const iv = combined.slice(0, 12);
    const ciphertext = combined.slice(12);
    const decrypted = await window.crypto.subtle.decrypt({ name: "AES-GCM", iv }, derivedKey, ciphertext);
    return new Uint8Array(decrypted);
  }

  private static async deriveKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
    const baseKey = await window.crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits", "deriveKey"]);
    return window.crypto.subtle.deriveKey({ name: "PBKDF2", salt, iterations: ITERATIONS, hash: "SHA-256" }, baseKey, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
  }

  static generateSecurePassword(length: number = 20): string {
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+~`|}{[]:;?><,./-=";
    const values = new Uint32Array(length);
    window.crypto.getRandomValues(values);
    return Array.from(values, v => charset[v % charset.length]).join('');
  }

  private static generateRecoveryHex(): string {
    const array = new Uint8Array(24);
    window.crypto.getRandomValues(array);
    return Array.from(array, dec => dec.toString(16).padStart(2, '0')).join('').toUpperCase();
  }

  private static bufToBase64(buf: Uint8Array): string { return btoa(String.fromCharCode(...buf)); }
  private static base64ToBuf(b64: string): Uint8Array { return new Uint8Array(atob(b64).split("").map(c => c.charCodeAt(0))); }
}
